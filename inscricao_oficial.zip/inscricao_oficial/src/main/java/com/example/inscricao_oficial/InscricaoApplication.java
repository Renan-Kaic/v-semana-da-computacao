package com.example.inscricao_oficial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InscricaoApplication {
    public static void main(String[] args) {
        SpringApplication.run(InscricaoApplication.class, args);
    }
}