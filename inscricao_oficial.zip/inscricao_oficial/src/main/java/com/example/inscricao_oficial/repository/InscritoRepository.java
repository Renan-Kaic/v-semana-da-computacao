package com.example.inscricao_oficial.repository;

import com.example.inscricao_oficial.model.Inscrito;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InscritoRepository extends JpaRepository<Inscrito, Long> {
}