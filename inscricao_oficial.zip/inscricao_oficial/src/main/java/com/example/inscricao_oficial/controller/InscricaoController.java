package com.example.inscricao_oficial.controller;

import com.example.inscricao_oficial.dto.InscricaoRequest;
import com.example.inscricao_oficial.model.Inscrito;
import com.example.inscricao_oficial.repository.InscritoRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class InscricaoController {

    private final InscritoRepository repository;

    public InscricaoController(InscritoRepository repository) {
        this.repository = repository;
    }

    @PostMapping("/inscricao")
    public ResponseEntity<String> inscrever(@RequestBody @Valid InscricaoRequest request) {
        Inscrito inscrito = new Inscrito();
        inscrito.setNome(request.getNome());
        inscrito.setEmail(request.getEmail());
        inscrito.setTelefone(request.getTelefone());
        repository.save(inscrito);
        return ResponseEntity.ok("Inscrição realizada com sucesso!");
    }

    @GetMapping("/admin/inscritos")
    public List<Inscrito> listarInscritos() {
        return repository.findAll();
    }
}