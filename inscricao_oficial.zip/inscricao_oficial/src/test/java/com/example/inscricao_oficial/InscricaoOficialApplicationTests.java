package com.example.inscricao_oficial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InscricaoOficialApplicationTests {

	@Test
	void contextLoads() {
	}

}
